import 'package:flutter/material.dart';
import 'package:upload_image/screen.dart';
void main()=>runApp(MaterialApp(
	title: "Android Developer",
  theme: ThemeData(
        primaryColor: Colors.pinkAccent,
      ),
  debugShowCheckedModeBanner: false,
  home: MyApp(title: "Android Developer"),
));
class MyApp extends StatefulWidget {
	final String title;
	MyApp({Key key,this.title}):super(key:key);
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with SingleTickerProviderStateMixin{
	
	int _currentTabIndex=0;
  HomeScreen homepage;
  OrderScreen orderPage;
  FavoriteScreen favoritePage;
  ProfileScreen profilePage;
  List<Widget> pages;
  Widget currentPage;




  Photo selectedPhotos=photos[0];
  String name="Sunil Shedge";
  String email="swarajya888@gmail.com";
  String backup1;
  String pic1="https://images.pexels.com/photos/1020315/pexels-photo-1020315.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260";
  String backup3;
  String name2="surya shinde";
  String email2="shedgersunil900@gmail.com";
  String backup2;
  String pic2="https://images.unsplash.com/photo-1502943693086-33b5b1cfdf2f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=668&q=80";
  void _selectedPhotos(Photo values){
    setState(() {
      selectedPhotos=values;
    });
  }
	TabController tabController;
	@override
	void initState() { 
		super.initState();
		setState(() {
			 homepage=HomeScreen();
    orderPage=OrderScreen();
    favoritePage=FavoriteScreen();
    profilePage=ProfileScreen();
    pages=[homepage,orderPage,favoritePage,profilePage];
    currentPage=homepage;
    super.initState();
		  refresh();
		
		});
	}
	void refresh() {
            setState(()
						{
                backup3=pic1;
                pic1=pic2;
                pic2=backup3;

                backup1=name;
                name=name2;
                name2=backup1;

                backup2=email;
                email=email2;
                email2=backup2;
          });
}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
				appBar: AppBar(
					title: Text(widget.title),
					
					actions: <Widget>[
						PopupMenuButton<Photo>(
							onSelected: _selectedPhotos,
							itemBuilder: (context){
							return photos.map((Photo photo){
								return PopupMenuItem<Photo>(
									value: photo,
									child: ListTile(
										leading: photo.icon,
										title: photo.title,
									),
								);
							}).toList();
						})
					],
				),
				bottomNavigationBar: BottomNavigationBar(
          elevation: 8.0,
          backgroundColor: Colors.white,
          fixedColor: Colors.lightBlue,
          onTap: (int index){
            setState(() {
              _currentTabIndex=index;
              currentPage=pages[index];
            });
          },
          currentIndex: _currentTabIndex,
          type: BottomNavigationBarType.fixed,
          items: <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.bookmark),
              title: Text("Explore",),
            ),

            BottomNavigationBarItem(
              icon: Icon(Icons.search),
              title: Text("search",),
            ),

            BottomNavigationBarItem(
              icon: Icon(Icons.shopping_cart),
              title: Text("Cart",),
            ),

            BottomNavigationBarItem(
              icon: Icon(Icons.account_circle),
              title: Text("Account",),
            ),
          ],

        ),
				body:currentPage,
        drawer: Drawer(
          child: ListView(
            children: <Widget>[
              UserAccountsDrawerHeader(
                decoration: BoxDecoration(
                  image: DecorationImage(image: NetworkImage(
                    "https://images.pexels.com/photos/1020315/pexels-photo-1020315.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"),
                  fit: BoxFit.fill,
                  ),
                ),
                accountName: Text(name),
               accountEmail: Text(email),
               currentAccountPicture: CircleAvatar(
                 
                 backgroundImage: NetworkImage(pic1),
               ),
               otherAccountsPictures: <Widget>[
                
                GestureDetector(
                  onTap: (){
                    setState(() {
                      refresh();
                   });
                },
                child: CircleAvatar(
                        backgroundImage: NetworkImage(pic2),
                 ),
),

                     
                   ],
      ),
                                     
     ],
    ),
  ),
                  
);
}
                      

}

class Photo
{
  final int id;
  final Text title;
  final Icon icon;
  final Image url;
  Photo(this.id,this.title,this.icon,this.url);
}
List<Photo> photos=[
  Photo(1,Text("Home",style: TextStyle(color: Colors.black),), Icon(Icons.home,color: Colors.black,), Image.network("https://images.pexels.com/photos/1020315/pexels-photo-1020315.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260")),
  Photo(2,Text("About",style: TextStyle(color: Colors.black),), Icon(Icons.info_outline,color: Colors.black,), Image.network("https://images.pexels.com/photos/1020315/pexels-photo-1020315.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260")),
  Photo(3,Text("Contact",style: TextStyle(color: Colors.black),), Icon(Icons.call,color: Colors.black), Image.network("https://images.pexels.com/photos/1020315/pexels-photo-1020315.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260")),
  Photo(4,Text("Portfolio",style: TextStyle(color: Colors.black),), Icon(Icons.image,color: Colors.black), Image.network("https://images.pexels.com/photos/1020315/pexels-photo-1020315.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260")),
];

class OrderScreen extends StatelessWidget {
	@override
	Widget build(BuildContext context) {
		return Scaffold(
			body: Center(child: Text("about")),
		);
	}
}
class FavoriteScreen extends StatelessWidget {
	@override
	Widget build(BuildContext context) {
		return Scaffold(
			body: Center(child: Text("contact")),
		);
	}
}
class ProfileScreen extends StatelessWidget {
	@override
	Widget build(BuildContext context) {
		return Scaffold(
			body: Center(child: Text("portfolio")),
		);
	}
}