
import 'package:flutter/material.dart';
void main()=>runApp(MaterialApp(
	title: "Android Developer",
  theme: ThemeData(
        primaryColor: Colors.pinkAccent,
      ),
  debugShowCheckedModeBanner: false,
  home: HomeScreen(title: "Android Developer"),
));
class HomeScreen extends StatefulWidget {
	final String title;
	HomeScreen({Key key,this.title}):super(key:key);
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin{
	





  Photo selectedPhotos=photos[0];
  String name="Sunil Shedge";
  String email="swarajya888@gmail.com";
  String backup1;
  String pic1="https://images.pexels.com/photos/1020315/pexels-photo-1020315.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260";
  String backup3;
  String name2="surya shinde";
  String email2="shedgersunil900@gmail.com";
  String backup2;
  String pic2="https://images.unsplash.com/photo-1502943693086-33b5b1cfdf2f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=668&q=80";
  void _selectedPhotos(Photo values){
    setState(() {
      selectedPhotos=values;
    });
  }
	TabController tabController;
	@override
	void initState() { 
		super.initState();
		setState(() {
			 
    super.initState();
		  refresh();
			tabController=new TabController(length: 4, vsync: this);
		});
	}
	void refresh() {
            setState(()
						{
                backup3=pic1;
                pic1=pic2;
                pic2=backup3;

                backup1=name;
                name=name2;
                name2=backup1;

                backup2=email;
                email=email2;
                email2=backup2;
          });
}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
				appBar: AppBar(
					title: Text(widget.title),
					bottom: TabBar(
						indicatorColor: Colors.white,
						controller: tabController,
						tabs: <Widget>[
						Tab(child: Text("Home"),),
						Tab(child: Text("About"),),
						Tab(child: Text("Contact"),),
						Tab(child: Text("Portfolio"),),
					]),
					actions: <Widget>[
						PopupMenuButton<Photo>(
							onSelected: _selectedPhotos,
							itemBuilder: (context){
							return photos.map((Photo photo){
								return PopupMenuItem<Photo>(
									value: photo,
									child: ListTile(
										leading: photo.icon,
										title: photo.title,
									),
								);
							}).toList();
						})
					],
				),
				
				body:TabBarView(
					controller: tabController,
					children: <Widget>[
						Center(child: Text("Home")),
						Center(child: Text("About")),
						Center(child: Text("Contact")),
						Center(child: Text("Portfolio")),
						
				]),
        drawer: Drawer(
          child: ListView(
            children: <Widget>[
              UserAccountsDrawerHeader(
                decoration: BoxDecoration(
                  image: DecorationImage(image: NetworkImage(
                    "https://images.pexels.com/photos/1020315/pexels-photo-1020315.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"),
                  fit: BoxFit.fill,
                  ),
                ),
                accountName: Text(name),
               accountEmail: Text(email),
               currentAccountPicture: CircleAvatar(
                 
                 backgroundImage: NetworkImage(pic1),
               ),
               otherAccountsPictures: <Widget>[
                
                GestureDetector(
                  onTap: (){
                    setState(() {
                      refresh();
                   });
                },
                child: CircleAvatar(
                        backgroundImage: NetworkImage(pic2),
                 ),
),

                     
                   ],
      ),
                                     
     ],
    ),
  ),
                  
);
}
                      

}

class Photo
{
  final int id;
  final Text title;
  final Icon icon;
  final Image url;
  Photo(this.id,this.title,this.icon,this.url);
}
List<Photo> photos=[
  Photo(1,Text("Home",style: TextStyle(color: Colors.black),), Icon(Icons.home,color: Colors.black,), Image.network("https://images.pexels.com/photos/1020315/pexels-photo-1020315.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260")),
  Photo(2,Text("About",style: TextStyle(color: Colors.black),), Icon(Icons.info_outline,color: Colors.black,), Image.network("https://images.pexels.com/photos/1020315/pexels-photo-1020315.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260")),
  Photo(3,Text("Contact",style: TextStyle(color: Colors.black),), Icon(Icons.call,color: Colors.black), Image.network("https://images.pexels.com/photos/1020315/pexels-photo-1020315.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260")),
  Photo(4,Text("Portfolio",style: TextStyle(color: Colors.black),), Icon(Icons.image,color: Colors.black), Image.network("https://images.pexels.com/photos/1020315/pexels-photo-1020315.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260")),
];

